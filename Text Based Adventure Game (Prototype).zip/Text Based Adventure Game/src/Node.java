public class Node {

    private int ID;
    private int northID;
    private int eastID;
    private int southID;
    private int westID;
    private String description;

    private Node northNode;
    private Node eastNode;
    private Node southNode;
    private Node westNode;

    public Node(int ID, int northID, int eastID, int southID, int westID, String description) {
        this.ID = ID;
        this.northID = northID;
        this.eastID = eastID;
        this.southID = southID;
        this.westID = westID;
        this.description = description;
    }

    public Node() {}

    public int getID() {
        return ID;
    }
    public void setID(int ID) {
        this.ID = ID;
    }
    public int getNorthID() {
        return northID;
    }
    public void setNorthID(int northID) {
        this.northID = northID;
    }
    public int getEastID() {return eastID;    }
    public void setEastID(int eastID) {
        this.eastID = eastID;
    }
    public int getSouthID() {
        return southID;
    }
    public void setSouthID(int southID) {
        this.southID = southID;
    }
    public int getWestID() {
        return westID;
    }
    public void setWestID(int westID) {
        this.westID = westID;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Node getNorthNode() {
        return northNode;
    }
    public void setNorthNode(Node left) {
        this.northNode = left;
    }
    public Node getEastNode() {
        return eastNode;
    }
    public void setEastNode(Node Right) {
        this.eastNode = Right;
    }
    public Node getSouthNode() {
        return southNode;
    }
    public void setSouthNode(Node Up) {
        this.southNode = Up;
    }
    public Node getWestNode() {
        return westNode;
    }
    public void setWestNode(Node Down) {
        this.westNode = Down;
    }





    @Override
    public String toString() {
        return "nodeID:" + ID +
                ", leftID:" + northID +
                ", rightID:" + eastID +
                ", upID:" + southID +
                ", downID:" + westID +
                ", description:'" + description + '\'';
    }
}