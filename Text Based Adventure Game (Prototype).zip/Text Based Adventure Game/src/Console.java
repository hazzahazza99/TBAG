import java.util.Scanner;

@SuppressWarnings("ALL")
public class Console {

     Scanner io;

    public Console(NodeMap map){

        io = new Scanner(System.in);

        while (map.currentNode() != null) {
            print(map.currentNode().getDescription());

            if (map.currentNode().getID() == 0) {
                startMenu();
                map.startDecision();
            } else {
                map.decision(
                        fromConsoleGetInt("North [1] East [2] South [3] or West [4]")
                ) ;
            }
        }

    }

    public  void print(String  info){
        System.out.println(info);
    }

    public  void lineBreak(){
        System.out.println("\n---------------");
    }

    public  void startMenu(){
        print("Press enter to start!");
        try { System.in.read();}
        catch(Exception e) {}
    }
    public  int fromConsoleGetInt(String prompt){
        print(prompt);
        int retVal = io.nextInt();
        return retVal;
    }


}
