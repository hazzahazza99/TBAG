import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static java.lang.Integer.valueOf;

public class Form {
    static int[] playerStats = {100,10,10}; //HP,ATK,DEF
    static int scoreTracker = 0;
    private static JFrame form;
    private static JTextArea ta;
    private static JPanel panel;
    private static JButton north;
    private static JButton east;
    private static JButton south;
    private static JButton west;
    private static JButton fight;
    private static JButton boost;
    private static JButton heal;
    private static JButton run;
    private static JTextArea score;

    public Form(NodeMap map) {
        createFrame(map);
        nodeDisplay(map);
        //battleScreen();
    }

    private static void createFrame(NodeMap map){
        form = new JFrame("Text Based Adventure Game");
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        form.setSize(1000,800);
        form.setResizable(false); //Disable the Resize Button
        form.setLocationRelativeTo(null);

        createPanel();
        createButtons(map);
        createTextArea();
        createScore();

        panel.add(north);
        panel.add(east);
        panel.add(south);
        panel.add(west);

        //Adding Components to the frame.
        form.getContentPane().add(BorderLayout.SOUTH, panel);
        form.getContentPane().add(BorderLayout.CENTER, ta);
        form.getContentPane().add(BorderLayout.NORTH, score);
        form.setVisible(true);


    }

    private static void battleScreen(){
        battleButtons();

        panel.remove(north);
        panel.remove(east);
        panel.remove(south);
        panel.remove(west);

        panel.add(fight);
        panel.add(boost);
        panel.add(heal);
        panel.add(run);

        ta.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
        ta.setLineWrap(true);

        form.getContentPane().add(BorderLayout.SOUTH, panel);
        form.getContentPane().add(BorderLayout.CENTER, ta);
        form.getContentPane().add(BorderLayout.NORTH, score);
        form.setVisible(true);


    }

    private static void createPanel(){
        panel = new JPanel(); // the panel is not visible in output
        setColors(panel, Color.darkGray,Color.black);
    }

    private static void createScore(){
        score = new JTextArea();
        score.setFont(createFont(20));
        score.setBackground(Color.darkGray);
        score.setForeground(Color.white);
        score.setText("Score:" + scoreTracker);
        score.setEditable(false);
    }

    private static void createButtons(NodeMap map){
        north = new JButton("North");
        north.setFont(createFont(50));
        setColors(north,Color.darkGray, Color.green);
        north.addActionListener((ActionEvent e) -> {
            move(map,1);
            nodeDisplay(map);
        });

        east = new JButton("East");
        east.setFont(createFont(50));
        setColors(east,Color.darkGray, Color.red);
        east.addActionListener((ActionEvent e) -> {
            move(map,2);
            nodeDisplay(map);
        });

        south = new JButton("South");
        south.setFont(createFont(50));
        setColors(south,Color.darkGray, Color.yellow);
        south.addActionListener((ActionEvent e) -> {
            move(map,3);
            nodeDisplay(map);
        });

        west = new JButton("West");
        west.setFont(createFont(50));
        setColors(west,Color.darkGray, Color.blue);
        west.addActionListener((ActionEvent e) -> {
            move(map,4);
            nodeDisplay(map);
        });
    }

    private static void battleButtons(){

        fight = new JButton("Fight");
        fight.setFont(createFont(50));
        setColors(fight,Color.darkGray, Color.red);
        fight.addActionListener((ActionEvent e) -> {
            //attack
        });
        boost = new JButton("Boost");
        boost.setFont(createFont(50));
        setColors(boost,Color.darkGray, Color.yellow);
        boost.addActionListener((ActionEvent e) -> {
            playerStats[1] = playerStats[1] + 5;
            playerStats[2] = playerStats[2] + 5;
            ta.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
        });
        heal = new JButton("Heal");
        heal.setFont(createFont(50));
        setColors(heal,Color.darkGray, Color.green);
        heal.addActionListener((ActionEvent e) -> {
            playerStats[0] = playerStats[0] + 25;
            ta.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
        });
        run = new JButton("Run");
        run.setFont(createFont(50));
        setColors(run,Color.darkGray, Color.blue);
        run.addActionListener((ActionEvent e) -> {
            //run
        });
    }


    private static void createTextArea(){
        ta = new JTextArea();
        ta.setFont(createFont(32));
        ta.setBackground(Color.darkGray);
        ta.setForeground(Color.red);
        ta.setEditable(false);
    }

    private static void move(NodeMap map, int direction) {
        if (map.currentNode().getID() == 0) {
            map.startDecision();
        } else {
            map.decision(direction);
            scoreTracker = scoreTracker + 100;
            score.setText("Score:" + scoreTracker); //this needs validation
        }
        if (map.currentNode().getID() == 1){
            //battleScreen();
        }
    }

    private static void nodeDisplay(NodeMap map){
        ta.setText(map.currentNode().getDescription());
        ta.setLineWrap(true);
        availableButtons(map);
            if (map.currentNode().getID() == 0) {
                north.setFont(createFont(40));
                north.setText("Start your adventure!");
                east.setVisible(false);
                south.setVisible(false);
                west.setVisible(false);
            } else {
                east.setVisible(true);
                south.setVisible(true);
                west.setVisible(true);
                north.setFont(createFont(50));
                north.setText("North");
            }
        }

    private static void availableButtons(NodeMap map){
        if (map.currentNode().getID() == map.currentNode().getNorthID()){
            setColors(north,Color.darkGray, Color.GRAY);
        }
        else{
            setColors(north,Color.darkGray, Color.green);
        }
        if (map.currentNode().getID() == map.currentNode().getEastID()){
            setColors(east,Color.darkGray, Color.GRAY);
        }
        else{
            setColors(east,Color.darkGray, Color.red);
        }
        if (map.currentNode().getID() == map.currentNode().getSouthID()){
            setColors(south,Color.darkGray, Color.GRAY);
        }
        else{
            setColors(south,Color.darkGray, Color.yellow);
        }
        if (map.currentNode().getID() == map.currentNode().getWestID()){
            setColors(west,Color.darkGray, Color.GRAY);
        }
        else{
            setColors(west,Color.darkGray, Color.blue);
        }
    }

    private static void setColors(JComponent object, Color bg, Color fg){
        object.setBackground(bg);
        object.setForeground(fg);
    }
    private static Font createFont(int size){
        return  new Font("Times New Roman", Font.PLAIN,size);
    }
}
