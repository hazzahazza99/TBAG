import static java.lang.Integer.valueOf;

public class TestNode {

    public static void main(String[] args){

        // NodeID / LeftID / RightID / UpID / Down ID / Description
        String line0 = "1,2,3,0,0,encounter 1";
        String line1 = "2,0,3,0,4,encounter 2";
        String line2 = "3,0,6,0,5,encounter 3";

        Node n0 = new Node();
        mapNode(n0, line0);
        Node n1 = new Node();
        mapNode(n1, line1);
        Node n2 = new Node();
        mapNode(n2, line2);

        n0.setNorthNode(n0);
        n0.setEastNode(n1);
        n0.setSouthNode(n2);
        n0.setWestNode(n0);

        System.out.println(n0.toString());
        System.out.println(n0.getNorthNode().toString());
        System.out.println(n0.getEastNode().toString());
        System.out.println(n0.getSouthNode().toString());
        System.out.println(n0.getWestNode().toString());

        ///System.out.println(mapNode());

    }

    public static void mapNode(Node n, String line){
        String[] stringArray = line.split(",");
        n.setID(valueOf(stringArray[0]));
        n.setNorthID(valueOf(stringArray[1]));
        n.setEastID(valueOf(stringArray[2]));
        n.setSouthID(Integer.valueOf(stringArray[3]));
        n.setWestID(Integer.valueOf(stringArray[4]));

        n.setDescription(stringArray[5]);
    }





}


