package com.example.tbagv2;

import static com.example.tbagv2.Form.nodeDisplay;
import static java.nio.file.Files.move;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    static int scoreTracker = 0;
    static TextView score;
    static TextView story;
    static ImageButton north;
    static ImageButton east;
    static ImageButton south;
    static ImageButton west;
    static Button fight;
    static Button quit;

    public void setScore(){
        if (scoreTracker < 0) {
            scoreTracker = 0;
        }
        score.setText("Score: " + String.valueOf(scoreTracker));
    }

    private static void move(NodeMap map, int direction) {
        if (map.currentNode().getID() == 0) {
            map.startDecision();
        } else {
            map.decision(direction);
            //scoreTracker = scoreTracker + 100;
            //score.setText("Score:" + scoreTracker); //this needs validation
        }
        if (map.currentNode().getID() == 1) {
            //battleScreen();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        score = findViewById(R.id.mainScore);
        story = findViewById(R.id.settingsInfo);
        north = findViewById(R.id.north);
        east = findViewById(R.id.east);
        south = findViewById(R.id.south);
        west = findViewById(R.id.west);
        fight = findViewById(R.id.fightButton);
        quit = findViewById(R.id.quit);



        NodeMap map = new NodeMap();
        if(map.currentNode() == null) {
            story.setText("null");
        }
        else{
            story.setText(map.currentNode().getDescription());
        }


        north.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                move(map,1);
                nodeDisplay(map);
                story.setText("node.north");
                scoreTracker = scoreTracker + 10;
                setScore();

            }
        });
        east.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                move(map,2);
                nodeDisplay(map);
                story.setText("node.east");
                scoreTracker = scoreTracker + 10;
                setScore();
            }
        });
        south.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                move(map,3);
                nodeDisplay(map);
                story.setText("node.south");
                scoreTracker = scoreTracker + 10;
                setScore();
            }
        });
        west.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                move(map,4);
                nodeDisplay(map);
                story.setText("node.west");
                scoreTracker = scoreTracker + 10;
                setScore();
            }
        });
        fight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), BattleActivity.class);
                startActivity(intent);
            }
        });
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    protected void onResume() {
        super.onResume();
        setScore();
    }
}