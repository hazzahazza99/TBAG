package com.example.tbagv2;

import static com.example.tbagv2.MainActivity.score;
import static com.example.tbagv2.StartingActivity.intro;

import java.io.FileNotFoundException;



public class  NodeMap {

    private Node head;
    private Node currentNode;

    public Node currentNode() { return currentNode;}

    public void startDecision(){
        currentNode = currentNode.getNorthNode();
    }

    public void decision(int decision) {
        switch (decision) {
            case 1:
                currentNode = currentNode.getNorthNode();
                break;
            case 2:
                currentNode = currentNode.getEastNode();
                break;
            case 3:
                currentNode = currentNode.getSouthNode();
                break;
            case 4:
                currentNode = currentNode.getWestNode();
                break;
        }
    }
    public NodeMap()  {
        NodeCollection nodeCollection;   //scope: constructor only, part of process, no requirement to keep;
        try {
            nodeCollection = new NodeCollection();
            head = nodeCollection.get(0);
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            return;
        }
        buildMap(nodeCollection);
        currentNode = head;
    }


    private void buildMap(NodeCollection nodeCollection)   {
        if (nodeCollection == null) {return;}
        for(Node source : nodeCollection.arrayList()){
            int leftID = source.getNorthID();
            int rightID = source.getEastID();
            int upID = source.getSouthID();
            int downID = source.getWestID();


            Node leftNode = nodeCollection.locateNodeBy(leftID);
            Node rightNode = nodeCollection.locateNodeBy(rightID);
            Node upNode = nodeCollection.locateNodeBy(upID);
            Node downNode = nodeCollection.locateNodeBy(downID);

            source.setNorthNode(leftNode);
            source.setEastNode(rightNode);
            source.setSouthNode(upNode);
            source.setWestNode(downNode);
        }
    }

    public String toString(){
        String string = "";
        string += northPath() + "\n";
        string += eastPath() + "\n";
        string += southPath() + "\n";
        string += westPath() + "\n";
        return string;
    }

    public String northPath(){
        Node node = head;
        String string = "North PATH\n";
        while(node != null) {
            string += node.toString() + "\n";
            node = node.getNorthNode();
            if (node.getID() == 0) { node = null;}
        }
        return string;
    }

    public String eastPath(){
        Node node = head;
        String string = "East PATH\n";
        while(node != null) {
            string += node.toString() + "\n";
            node = node.getEastNode();
            if (node.getID() == 0) { node = null;}
        }
        return string;
    }

    public String southPath(){
        Node node = head;
        String string = "South PATH\n";
        while(node != null) {
            string += node.toString() + "\n";
            node = node.getSouthNode();
            if (node.getID() == 0) { node = null;}
        }
        return string;
    }

    public String westPath(){
        Node node = head;
        String string = "West PATH\n";
        while(node != null) {
            string += node.toString() + "\n";
            node = node.getWestNode();
            if (node.getID() == 0) { node = null;}
        }
        return string;
    }
}