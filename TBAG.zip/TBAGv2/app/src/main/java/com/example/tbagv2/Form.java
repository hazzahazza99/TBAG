package com.example.tbagv2;

import android.view.View;

public class Form {

    public Form(NodeMap map) {
        nodeDisplay(map);
        createButtons(map);
    }


    static void nodeDisplay(NodeMap map) {
        MainActivity.story.setText(map.currentNode().getDescription());
        availableButtons(map);
        if (map.currentNode().getID() == 0) {
            MainActivity.story.setText("Start your adventure!");
        }
        else{
            map.currentNode().setID(1);
        }
    }

    private static void availableButtons(NodeMap map) {
        if (map.currentNode().getID() == map.currentNode().getNorthID()) {
            MainActivity.north.setVisibility(View.GONE);
        } else {
            MainActivity.north.setVisibility(View.VISIBLE);
        }
        if (map.currentNode().getID() == map.currentNode().getEastID()) {
            MainActivity.east.setVisibility(View.GONE);
        } else {
            MainActivity.east.setVisibility(View.VISIBLE);
        }
        if (map.currentNode().getID() == map.currentNode().getSouthID()) {
            MainActivity.south.setVisibility(View.GONE);
        } else {
            MainActivity.south.setVisibility(View.VISIBLE);
        }
        if (map.currentNode().getID() == map.currentNode().getWestID()) {
            MainActivity.west.setVisibility(View.GONE);
        } else {
            MainActivity.west.setVisibility(View.VISIBLE);
        }
    }

    private static void move(NodeMap map, int direction) {
        if (map.currentNode().getID() == 0) {
            map.startDecision();
        } else {
            map.decision(direction);
            //scoreTracker = scoreTracker + 100;
            //score.setText("Score:" + scoreTracker); //this needs validation
        }
        if (map.currentNode().getID() == 1) {
            //battleScreen();
        }
    }

    private static void createButtons(NodeMap map) {

        MainActivity.north.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //move(map,1);
                //nodeDisplay(map);
                MainActivity.story.setText("north");
            }
        });
        MainActivity.east.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //move(map,2);
                //nodeDisplay(map);
                MainActivity.story.setText("east");
            }
        });
        MainActivity.south.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //move(map,3);
                //nodeDisplay(map);
                MainActivity.story.setText("south");
            }
        });
        MainActivity.west.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //move(map,4);
                //nodeDisplay(map);
                MainActivity.story.setText("west");
            }
        });
        MainActivity.fight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(getBaseContext(), BattleActivity.class);
                //startActivity(intent);
            }
        });
        MainActivity.quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(Intent.ACTION_MAIN);
                //intent.addCategory(Intent.CATEGORY_HOME);
                //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                //startActivity(intent);
            }
        });
    }
}
