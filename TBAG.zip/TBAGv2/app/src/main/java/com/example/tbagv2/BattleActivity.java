package com.example.tbagv2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.lang.Math;

import androidx.appcompat.app.AppCompatActivity;

public class BattleActivity extends AppCompatActivity {

    static int[] playerStats = {100, 10, 10}; //HP,ATK,DEF
    static int enemyHealth = 100;
    int min = 1;
    int max = 8;
    TextView battleDescription;
    TextView enemyHP;
    Button fight;
    Button heal;
    Button boost;
    Button run;

    private void winCondition() {
        if (playerStats[0] < 0) {
            MainActivity.scoreTracker = MainActivity.scoreTracker - 50;
            Intent intent = new Intent(getBaseContext(), MainActivity.class);
            startActivity(intent);
        }
        if (enemyHealth < 0) {
            MainActivity.scoreTracker = MainActivity.scoreTracker + 100;
            Intent intent = new Intent(getBaseContext(), MainActivity.class);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_battle);


        battleDescription = findViewById(R.id.settingsInfo);
        fight = findViewById(R.id.difficultyChange);
        heal = findViewById(R.id.highscores);
        boost = findViewById(R.id.saveGame);
        run = findViewById(R.id.settingsBack);
        enemyHP = findViewById(R.id.enemyHP);

        battleDescription.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
        enemyHP.setText("Enemy HP: " + String.valueOf(enemyHealth));



        fight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                winCondition();
                MainActivity.scoreTracker = MainActivity.scoreTracker + 10;
                enemyHealth = enemyHealth - playerStats[1];
                int dmg = (int)(Math.random()*(max-min+1)+min);
                playerStats[0] = playerStats[0]- (10 * dmg) + playerStats[2];
                battleDescription.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
                enemyHP.setText("Enemy HP: " + String.valueOf(enemyHealth));
            }
        });
        heal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                winCondition();
                MainActivity.scoreTracker = MainActivity.scoreTracker + 5;
                playerStats[0] = 100;
                battleDescription.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
                enemyHP.setText("Enemy HP: " + String.valueOf(enemyHealth));
            }

        });
        boost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                winCondition();
                MainActivity.scoreTracker = MainActivity.scoreTracker + 5;
                playerStats[1] = playerStats[1] + 5;
                playerStats[2] = playerStats[2] + 5;
                int dmg = (int)(Math.random()*(max-min+1)+min);
                playerStats[0] = playerStats[0]- (10 * dmg)+ playerStats[2];
                battleDescription.setText("Battle!\n\nPlayer Stats:\nHP: " + playerStats[0] + " ATK: " + playerStats[1] + " DEF: " + playerStats[2]);
                enemyHP.setText("Enemy HP: " + String.valueOf(enemyHealth));
            }
        });
        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.scoreTracker = MainActivity.scoreTracker - 50;
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
    protected void onResume(){
        super.onResume();
        enemyHealth = 100;
        playerStats = new int[]{100, 10, 10};
    }
}