package com.example.tbagv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SettingsActivity extends AppCompatActivity {

    TextView settingsInfo;
    Button difficultyChange;
    Button saveGame;
    Button highscores;
    Button back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        settingsInfo = findViewById(R.id.settingsInfo);
        difficultyChange = findViewById(R.id.difficultyChange);
        saveGame = findViewById(R.id.saveGame);
        highscores = findViewById(R.id.highscores);
        back = findViewById(R.id.settingsBack);


        difficultyChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingsInfo.setText("Coming Soon");
            }
        });

        highscores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String score = String.valueOf(MainActivity.scoreTracker);
                settingsInfo.setText("High score: " + score);
            }
        });

        saveGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingsInfo.setText("Coming Soon");
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingsInfo.setText("Settings");
                Intent intent = new Intent(getBaseContext(), StartingActivity.class);
                startActivity(intent);
            }
        });
    }
}